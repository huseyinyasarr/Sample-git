echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -HOSTNAME: | more >> pc-information-ubuntu.txt
hostname| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -USERNAME:| more >> pc-information-ubuntu.txt
whoami| more >> pc-information-ubuntu.txt

echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -enter your password
echo -CURRENT WORKING DIRECTORY:| more >> pc-information-ubuntu.txt
pwd commend| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -CURRENT RUNNING APPLICATIONS and SERVICES:| more >> pc-information-ubuntu.txt
ps -aux| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -CURRENT OPENED PORTS| more >> pc-information-ubuntu.txt
sudo lsof -i -P -n | grep LISTEN| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -AVAILABLE MEMORY SPACE:| more >> pc-information-ubuntu.txt
free -m| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -AVAILABLE HARDISK SPACE:| more >> pc-information-ubuntu.txt
df -h| more >> pc-information-ubuntu.txt

echo ----------------------------------| more >> pc-information-ubuntu.txt
echo ----------------------------------| more >> pc-information-ubuntu.txt
echo -FINISHED| more >> pc-information-ubuntu.txt

